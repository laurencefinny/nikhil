import React from "react";
import "./App.css";
import Navbar from "./head/Navbar";

function App() {
  return (
    <div>
      <Navbar></Navbar>
    </div>
  );
}

export default App;
