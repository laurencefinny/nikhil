import React from 'react';
// import { MDBContainer, MDBFooter } from "mdbreact";
import "../head/navbar.css"

const Footer = () => {

    return (

        <footer>
            <div className="footer">
                <p class="pt-3 ml-4">Copyright &copy; 2019</p>
            </div>
        </footer>
        // <MDBFooter style={{ backgroundColor: '#0000b3' }} className="font-small footer-copyright text-center py-3 mt-3">

        //     <MDBContainer fluid  >
        //         ©2020 Outreach Feedback Management System -Cognizant All Rights Reserved
        //     </MDBContainer>

        // </MDBFooter>
    );

}

export default Footer